package com.jattkaim;

import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;
import sun.tools.jstat.Literal;

import java.util.*;

public class Main {



    static String[][] c;
    public static void main(String[] args) {
        MiningHelper mine = new MiningHelper();

        Scanner sc = new Scanner(System.in);

      System.out.println("Please Enter a Review for your doctor: ");
      //String review = sc.next();

      String ads[] = {"and","but","so"};
      String review = "This doctor was not very good and took too long, so im giving him two stars. this is me breaking up the sentences";
      String a[]=review.split("\\. |\\? |\\! ");
      System.out.println("Original review Sentence: "+review);
      System.out.println("");
      System.out.println("Breaking up the sentences: ");

      /*Displaying the two sentences*/

      for (String b:a){
          System.out.println("  "+b);
      }
        /*setting 2D array with [Sentence] [array of words in that sentence]*/
        c= new String[a.length][];
        for (int i=0;i<a.length;i++){
          String temp[]=a[i].split(" |, ");

            for(int j=0;j<temp.length;j++){
                c[i]=temp;
            }
      }

        /*Print statements for all words in each sentence*/
        System.out.println("");
        System.out.println("--------------------------------");
        System.out.println("");
      for (int i =0;i<c.length;i++){

          System.out.print("the "+c[i].length+" words in sentence "+i+" are: ");
          for (int j=00; j<c[i].length;j++){
              System.out.print(","+c[i][j]);

          }
          System.out.println("");
          System.out.println("");
      }


        /*RUN METHOD TO FIND ADVERBS/CONJUNCTIONS*/
      mine.findAdverbs(c,ads);

    }





}
