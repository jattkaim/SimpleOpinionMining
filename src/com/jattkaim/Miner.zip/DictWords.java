package com.jattkaim;

import java.util.Arrays;
import java.util.List;

public class DictWords {
    public static List<Dict> wordsList = Arrays.asList(

            new Dict("good",0,"Pos",7),
            new Dict("great",0,"Pos",8),
            new Dict("annoyed",0,"Pos",3),
            new Dict("furious",0,"Pos",1),
            new Dict("long",0,"Pos",3));
}

